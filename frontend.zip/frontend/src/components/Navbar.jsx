import { Link, NavLink } from "react-router-dom";

function Navbar() {
  const navLinkClass = ({ isActive }) =>
    `font-medium transition ${
      isActive
        ? "text-primary"
        : "hover:text-primary"
    }`;

  return (
    <div className="navbar bg-base-100 shadow-md px-4 md:px-8 sticky top-0 z-50">

      {/* Logo */}
      <div className="navbar-start">
        <Link
          to="/"
          className="text-2xl md:text-3xl font-bold text-primary"
        >
          ShopNow
        </Link>
      </div>

      {/* Desktop Menu */}
      <div className="navbar-center hidden lg:flex">
        <ul className="menu menu-horizontal px-1 gap-2">

          <li>
            <NavLink to="/" className={navLinkClass}>
              Home
            </NavLink>
          </li>

          <li>
            <NavLink to="/products" className={navLinkClass}>
              Products
            </NavLink>
          </li>

          <li>
            <NavLink to="/orders" className={navLinkClass}>
              Orders
            </NavLink>
          </li>

          <li>
            <NavLink to="/profile" className={navLinkClass}>
              Profile
            </NavLink>
          </li>

        </ul>
      </div>

      {/* Right Side */}
      <div className="navbar-end gap-2">

        {/* Cart */}
        <Link
          to="/cart"
          className="btn btn-ghost btn-circle"
          title="Shopping Cart"
        >
          🛒
        </Link>

        {/* Login */}
        <Link
          to="/login"
          className="btn btn-primary btn-sm hidden sm:flex"
        >
          Login
        </Link>

        {/* Mobile Menu */}
        <div className="dropdown dropdown-end lg:hidden">

          <label
            tabIndex={0}
            className="btn btn-ghost btn-circle"
          >
            ☰
          </label>

          <ul
            tabIndex={0}
            className="menu dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow-lg"
          >

            <li>
              <Link to="/">Home</Link>
            </li>

            <li>
              <Link to="/products">Products</Link>
            </li>

            <li>
              <Link to="/orders">Orders</Link>
            </li>

            <li>
              <Link to="/profile">Profile</Link>
            </li>

            <li>
              <Link to="/cart">🛒 Cart</Link>
            </li>

            <li>
              <Link to="/login">Login</Link>
            </li>

            <li>
              <Link to="/signup">Create Account</Link>
            </li>

          </ul>

        </div>

      </div>

    </div>
  );
}

export default Navbar;