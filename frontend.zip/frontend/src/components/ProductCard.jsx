import { Link } from "react-router-dom";

function ProductCard({ product, onAddToCart }) {

  // Backend me image ka field image / imageurl dono ho sakta hai
  const imagePath = product.image || product.imageurl;

  // Image URL prepare karna
  const getImageUrl = (image) => {
    if (!image) return null;

    // Agar already complete URL hai
    if (image.startsWith("http://") || image.startsWith("https://")) {
      return image;
    }

    // Windows path ko normal URL path me convert karo
    const cleanPath = image
      .replace(/\\/g, "/")
      .replace(/^\/+/, "");

    return `http://localhost:3000/${cleanPath}`;
  };

  const imageUrl = getImageUrl(imagePath);

  return (
    <div className="card bg-base-100 shadow-md hover:shadow-xl transition duration-300">

      {/* Product Image */}
      <figure className="h-56 bg-base-300 flex items-center justify-center overflow-hidden">

        {imageUrl ? (
          <img
            src={imageUrl}
            alt={product.name || "Product"}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.style.display = "none";
            }}
          />
        ) : (
          <span className="text-7xl">
            🛍️
          </span>
        )}

      </figure>

      {/* Product Details */}
      <div className="card-body">

        {/* Category */}
        {product.category && (
          <div className="badge badge-outline w-fit">
            {product.category}
          </div>
        )}

        {/* Product Name */}
        <h2 className="card-title mt-2">
          {product.name}
        </h2>

        {/* Description */}
        {product.description && (
          <p className="text-sm opacity-60 line-clamp-2">
            {product.description}
          </p>
        )}

        {/* Price */}
        <p className="text-xl font-bold text-primary mt-2">
          ₹{product.price}
        </p>

        {/* Buttons */}
        <div className="card-actions mt-3">

          <Link
            to={`/product/${product._id || product.id}`}
            className="btn btn-outline btn-sm"
          >
            View Details
          </Link>

          <button
            onClick={() => onAddToCart?.(product)}
            className="btn btn-primary btn-sm flex-1"
          >
            🛒 Add to Cart
          </button>

        </div>

      </div>
    </div>
  );
}

export default ProductCard;