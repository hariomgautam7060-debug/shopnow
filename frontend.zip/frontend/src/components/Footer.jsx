import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer className="bg-neutral text-neutral-content">

      <div className="max-w-7xl mx-auto px-6 py-12">

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

          {/* Brand */}
          <div>
            <Link
              to="/"
              className="text-3xl font-bold text-primary"
            >
              ShopNow
            </Link>

            <p className="mt-4 text-sm opacity-70 leading-6">
              Your one-stop destination for quality products,
              great prices and a smooth shopping experience.
            </p>

            {/* Social */}
            <div className="flex gap-3 mt-5">
              <button className="btn btn-circle btn-sm">
                f
              </button>

              <button className="btn btn-circle btn-sm">
                in
              </button>

              <button className="btn btn-circle btn-sm">
                X
              </button>

              <button className="btn btn-circle btn-sm">
                ◎
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">
              Quick Links
            </h3>

            <div className="flex flex-col gap-3 text-sm">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>

              <Link to="/products" className="hover:text-primary">
                Products
              </Link>

              <Link to="/cart" className="hover:text-primary">
                Cart
              </Link>

              <Link to="/orders" className="hover:text-primary">
                My Orders
              </Link>
            </div>
          </div>

          {/* Account */}
          <div>
            <h3 className="font-bold text-lg mb-4">
              Account
            </h3>

            <div className="flex flex-col gap-3 text-sm">
              <Link to="/login" className="hover:text-primary">
                Login
              </Link>

              <Link to="/signup" className="hover:text-primary">
                Create Account
              </Link>

              <Link to="/profile" className="hover:text-primary">
                My Profile
              </Link>

              <Link to="/orders" className="hover:text-primary">
                Order History
              </Link>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-lg mb-4">
              Contact Us
            </h3>

            <div className="flex flex-col gap-4 text-sm opacity-80">

              <p>
                📧 support@shopnow.com
              </p>

              <p>
                📞 +91 98765 43210
              </p>

              <p>
                📍 India
              </p>

            </div>
          </div>

        </div>

        <div className="divider opacity-20"></div>

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-3 text-sm opacity-60">

          <p>
            © 2026 ShopNow. All rights reserved.
          </p>

          <div className="flex gap-5">
            <button className="hover:text-primary">
              Privacy Policy
            </button>

            <button className="hover:text-primary">
              Terms & Conditions
            </button>
          </div>

        </div>

      </div>

    </footer>
  );
}

export default Footer;