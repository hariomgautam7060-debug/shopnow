import { Link } from "react-router-dom";

const orders = [
  {
    id: "SN1001",
    date: "28 September 2026",
    status: "Delivered",
    total: 2298,
    items: [
      {
        name: "Wireless Headphones",
        price: 1499,
        quantity: 1,
        emoji: "🎧",
      },
      {
        name: "Casual T-Shirt",
        price: 799,
        quantity: 1,
        emoji: "👕",
      },
    ],
  },
  {
    id: "SN1002",
    date: "20 September 2026",
    status: "Shipped",
    total: 2499,
    items: [
      {
        name: "Smart Watch",
        price: 2499,
        quantity: 1,
        emoji: "⌚",
      },
    ],
  },
  {
    id: "SN1003",
    date: "15 September 2026",
    status: "Processing",
    total: 1999,
    items: [
      {
        name: "Running Shoes",
        price: 1999,
        quantity: 1,
        emoji: "👟",
      },
    ],
  },
];

function Orders() {
  return (
    <div className="min-h-screen bg-base-200 px-6 py-10">

      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold">
            My Orders
          </h1>

          <p className="mt-2 opacity-60">
            Track and manage your recent orders
          </p>
        </div>

        {/* Orders */}
        <div className="space-y-6">

          {orders.map((order) => (
            <div
              key={order.id}
              className="card bg-base-100 shadow-md"
            >

              <div className="card-body">

                {/* Order Header */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

                  <div>
                    <p className="text-sm opacity-60">
                      Order ID
                    </p>

                    <h2 className="text-xl font-bold">
                      #{order.id}
                    </h2>

                    <p className="text-sm opacity-60 mt-1">
                      Ordered on {order.date}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">

                    <span
                      className={`badge badge-lg ${
                        order.status === "Delivered"
                          ? "badge-success"
                          : order.status === "Shipped"
                          ? "badge-info"
                          : "badge-warning"
                      }`}
                    >
                      {order.status}
                    </span>

                    <span className="text-xl font-bold">
                      ₹{order.total}
                    </span>

                  </div>

                </div>

                <div className="divider"></div>

                {/* Products */}
                <div className="space-y-4">

                  {order.items.map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-4"
                    >

                      {/* Product Image */}
                      <div className="w-20 h-20 rounded-xl bg-base-300 flex items-center justify-center">
                        <span className="text-4xl">
                          {item.emoji}
                        </span>
                      </div>

                      {/* Product Details */}
                      <div className="flex-1">

                        <h3 className="font-semibold">
                          {item.name}
                        </h3>

                        <p className="text-sm opacity-60">
                          Quantity: {item.quantity}
                        </p>

                      </div>

                      <p className="font-bold">
                        ₹{item.price * item.quantity}
                      </p>

                    </div>
                  ))}

                </div>

                <div className="divider"></div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row justify-between gap-3">

                  <button className="btn btn-outline btn-sm">
                    View Order Details
                  </button>

                  {order.status === "Delivered" && (
                    <button className="btn btn-outline btn-sm">
                      Buy Again
                    </button>
                  )}

                  {order.status === "Shipped" && (
                    <button className="btn btn-primary btn-sm">
                      Track Order
                    </button>
                  )}

                </div>

              </div>

            </div>
          ))}

        </div>

        {/* Continue Shopping */}
        <div className="text-center mt-10">

          <Link
            to="/products"
            className="btn btn-primary"
          >
            Continue Shopping
          </Link>

        </div>

      </div>

    </div>
  );
}

export default Orders;