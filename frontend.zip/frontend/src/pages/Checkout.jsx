import { Link } from "react-router-dom";

function Checkout() {
  const subtotal = 2298;
  const delivery = 99;
  const total = subtotal + delivery;

  return (
    <div className="min-h-screen bg-base-200 px-6 py-10">

      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold">
            Checkout
          </h1>

          <p className="mt-2 opacity-60">
            Complete your order securely
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">

          {/* Left Side */}
          <div className="lg:col-span-2 space-y-6">

            {/* Shipping Address */}
            <div className="card bg-base-100 shadow-md">
              <div className="card-body">

                <h2 className="card-title text-2xl">
                  📍 Shipping Address
                </h2>

                <div className="grid md:grid-cols-2 gap-5 mt-4">

                  <fieldset className="fieldset">
                    <legend className="fieldset-legend">
                      Full Name
                    </legend>

                    <input
                      type="text"
                      placeholder="Enter full name"
                      className="input input-bordered w-full"
                    />
                  </fieldset>

                  <fieldset className="fieldset">
                    <legend className="fieldset-legend">
                      Phone Number
                    </legend>

                    <input
                      type="tel"
                      placeholder="Enter phone number"
                      className="input input-bordered w-full"
                    />
                  </fieldset>

                  <fieldset className="fieldset md:col-span-2">
                    <legend className="fieldset-legend">
                      Address
                    </legend>

                    <textarea
                      placeholder="House no, street, area"
                      className="textarea textarea-bordered w-full h-24"
                    ></textarea>
                  </fieldset>

                  <fieldset className="fieldset">
                    <legend className="fieldset-legend">
                      City
                    </legend>

                    <input
                      type="text"
                      placeholder="Enter city"
                      className="input input-bordered w-full"
                    />
                  </fieldset>

                  <fieldset className="fieldset">
                    <legend className="fieldset-legend">
                      State
                    </legend>

                    <input
                      type="text"
                      placeholder="Enter state"
                      className="input input-bordered w-full"
                    />
                  </fieldset>

                  <fieldset className="fieldset">
                    <legend className="fieldset-legend">
                      Pincode
                    </legend>

                    <input
                      type="text"
                      placeholder="Enter pincode"
                      className="input input-bordered w-full"
                    />
                  </fieldset>

                </div>

              </div>
            </div>

            {/* Payment */}
            <div className="card bg-base-100 shadow-md">
              <div className="card-body">

                <h2 className="card-title text-2xl">
                  💳 Payment Method
                </h2>

                <div className="space-y-4 mt-5">

                  {/* UPI */}
                  <label className="border rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:bg-base-200">
                    <input
                      type="radio"
                      name="payment"
                      className="radio radio-primary"
                    />

                    <div>
                      <h3 className="font-semibold">
                        UPI
                      </h3>

                      <p className="text-sm opacity-60">
                        Pay using Google Pay, PhonePe, Paytm etc.
                      </p>
                    </div>
                  </label>

                  {/* Card */}
                  <label className="border rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:bg-base-200">
                    <input
                      type="radio"
                      name="payment"
                      className="radio radio-primary"
                    />

                    <div>
                      <h3 className="font-semibold">
                        Credit / Debit Card
                      </h3>

                      <p className="text-sm opacity-60">
                        Pay securely using your card.
                      </p>
                    </div>
                  </label>

                  {/* COD */}
                  <label className="border rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:bg-base-200">
                    <input
                      type="radio"
                      name="payment"
                      className="radio radio-primary"
                    />

                    <div>
                      <h3 className="font-semibold">
                        Cash on Delivery
                      </h3>

                      <p className="text-sm opacity-60">
                        Pay when your order arrives.
                      </p>
                    </div>
                  </label>

                </div>

              </div>
            </div>

          </div>

          {/* Order Summary */}
          <div>

            <div className="card bg-base-100 shadow-xl sticky top-6">

              <div className="card-body">

                <h2 className="card-title text-2xl">
                  Order Summary
                </h2>

                {/* Product */}
                <div className="flex items-center gap-4 mt-5">

                  <div className="w-16 h-16 bg-base-300 rounded-lg flex items-center justify-center">
                    <span className="text-3xl">
                      🎧
                    </span>
                  </div>

                  <div className="flex-1">
                    <h3 className="font-semibold">
                      Wireless Headphones
                    </h3>

                    <p className="text-sm opacity-60">
                      Qty: 1
                    </p>
                  </div>

                  <span className="font-semibold">
                    ₹1499
                  </span>

                </div>

                {/* Product */}
                <div className="flex items-center gap-4 mt-4">

                  <div className="w-16 h-16 bg-base-300 rounded-lg flex items-center justify-center">
                    <span className="text-3xl">
                      👕
                    </span>
                  </div>

                  <div className="flex-1">
                    <h3 className="font-semibold">
                      Casual T-Shirt
                    </h3>

                    <p className="text-sm opacity-60">
                      Qty: 1
                    </p>
                  </div>

                  <span className="font-semibold">
                    ₹799
                  </span>

                </div>

                <div className="divider"></div>

                {/* Price */}
                <div className="flex justify-between">
                  <span className="opacity-70">
                    Subtotal
                  </span>

                  <span>
                    ₹{subtotal}
                  </span>
                </div>

                <div className="flex justify-between mt-3">
                  <span className="opacity-70">
                    Delivery
                  </span>

                  <span>
                    ₹{delivery}
                  </span>
                </div>

                <div className="divider"></div>

                <div className="flex justify-between text-xl">
                  <span className="font-bold">
                    Total
                  </span>

                  <span className="font-bold text-primary">
                    ₹{total}
                  </span>
                </div>

                {/* Place Order */}
                <button className="btn btn-primary w-full mt-5">
                  Place Order
                </button>

                <p className="text-xs text-center opacity-60 mt-3">
                  🔒 Your payment and personal information are secure.
                </p>

                <Link
                  to="/cart"
                  className="btn btn-ghost btn-sm mt-2"
                >
                  ← Back to Cart
                </Link>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Checkout;