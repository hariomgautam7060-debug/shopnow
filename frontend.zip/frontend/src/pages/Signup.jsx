import { Link } from "react-router-dom";

function Signup() {
  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center px-6 py-12">

      <div className="w-full max-w-md">

        {/* Logo / Heading */}
        <div className="text-center mb-8">
          <Link
            to="/"
            className="text-3xl font-bold text-primary"
          >
            ShopNow
          </Link>

          <h1 className="text-3xl font-bold mt-5">
            Create Your Account
          </h1>

          <p className="opacity-60 mt-2">
            Join ShopNow and start shopping
          </p>
        </div>

        {/* Signup Card */}
        <div className="card bg-base-100 shadow-xl">

          <div className="card-body">

            {/* Name */}
            <fieldset className="fieldset">
              <legend className="fieldset-legend">
                Full Name
              </legend>

              <input
                type="text"
                className="input input-bordered w-full"
                placeholder="Enter your full name"
              />
            </fieldset>

            {/* Email */}
            <fieldset className="fieldset mt-2">
              <legend className="fieldset-legend">
                Email Address
              </legend>

              <input
                type="email"
                className="input input-bordered w-full"
                placeholder="Enter your email"
              />
            </fieldset>

            {/* Password */}
            <fieldset className="fieldset mt-2">
              <legend className="fieldset-legend">
                Password
              </legend>

              <input
                type="password"
                className="input input-bordered w-full"
                placeholder="Create a password"
              />
            </fieldset>

            {/* Confirm Password */}
            <fieldset className="fieldset mt-2">
              <legend className="fieldset-legend">
                Confirm Password
              </legend>

              <input
                type="password"
                className="input input-bordered w-full"
                placeholder="Confirm your password"
              />
            </fieldset>

            {/* Terms */}
            <label className="label cursor-pointer justify-start gap-3 mt-4">

              <input
                type="checkbox"
                className="checkbox checkbox-primary checkbox-sm"
              />

              <span className="text-sm">
                I agree to the{" "}
                <span className="text-primary">
                  Terms & Conditions
                </span>
              </span>

            </label>

            {/* Signup Button */}
            <button className="btn btn-primary w-full mt-4">
              Create Account
            </button>

            {/* Divider */}
            <div className="divider">
              OR
            </div>

            {/* Google */}
            <button className="btn btn-outline w-full">
              Continue with Google
            </button>

            {/* Login */}
            <p className="text-center mt-5 text-sm">
              Already have an account?{" "}
              <Link
                to="/login"
                className="text-primary font-semibold hover:underline"
              >
                Login
              </Link>
            </p>

          </div>

        </div>

        {/* Back */}
        <div className="text-center mt-6">
          <Link
            to="/"
            className="text-sm opacity-60 hover:opacity-100"
          >
            ← Back to ShopNow
          </Link>
        </div>

      </div>

    </div>
  );
}

export default Signup;