import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="bg-base-200 min-h-screen">

      {/* Hero Section */}
      <section className="hero min-h-[70vh] bg-base-100">
        <div className="hero-content text-center">
          <div className="max-w-3xl">

            <div className="badge badge-primary mb-4">
              Welcome to ShopNow
            </div>

            <h1 className="text-5xl md:text-6xl font-bold">
              Everything You Need,
              <span className="text-primary"> In One Place</span>
            </h1>

            <p className="py-6 text-lg opacity-70">
              Discover amazing products at great prices.
              Shop your favorite products quickly and easily
              with ShopNow.
            </p>

            <div className="flex justify-center gap-4">
              <Link
                to="/products"
                className="btn btn-primary"
              >
                Shop Now
              </Link>

              <Link
                to="/products"
                className="btn btn-outline"
              >
                Explore Products
              </Link>
            </div>

          </div>
        </div>
      </section>


      {/* Categories */}
      <section className="py-16 px-6">

        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold">
            Shop By Category
          </h2>

          <p className="opacity-60 mt-2">
            Find what you're looking for
          </p>
        </div>


        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-6xl mx-auto">

          <div className="card bg-base-100 shadow-md hover:shadow-xl transition">
            <div className="card-body items-center text-center">
              <div className="text-5xl">👕</div>
              <h3 className="card-title">Fashion</h3>
              <p className="opacity-60">
                Latest fashion products
              </p>
            </div>
          </div>


          <div className="card bg-base-100 shadow-md hover:shadow-xl transition">
            <div className="card-body items-center text-center">
              <div className="text-5xl">📱</div>
              <h3 className="card-title">Electronics</h3>
              <p className="opacity-60">
                Latest gadgets & devices
              </p>
            </div>
          </div>


          <div className="card bg-base-100 shadow-md hover:shadow-xl transition">
            <div className="card-body items-center text-center">
              <div className="text-5xl">🏠</div>
              <h3 className="card-title">Home</h3>
              <p className="opacity-60">
                Products for your home
              </p>
            </div>
          </div>


          <div className="card bg-base-100 shadow-md hover:shadow-xl transition">
            <div className="card-body items-center text-center">
              <div className="text-5xl">🎮</div>
              <h3 className="card-title">Gaming</h3>
              <p className="opacity-60">
                Gaming products & accessories
              </p>
            </div>
          </div>

        </div>

      </section>


      {/* Featured Section */}
      <section className="py-16 px-6 bg-base-100">

        <div className="max-w-6xl mx-auto">

          <div className="flex justify-between items-center mb-8">

            <div>
              <h2 className="text-3xl font-bold">
                Featured Products
              </h2>

              <p className="opacity-60 mt-1">
                Explore our popular products
              </p>
            </div>

            <Link
              to="/products"
              className="btn btn-outline btn-sm"
            >
              View All
            </Link>

          </div>


          {/* Temporary Product Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">

            {[1, 2, 3, 4].map((item) => (

              <div
                key={item}
                className="card bg-base-200 shadow-md hover:shadow-xl transition"
              >

                <figure className="h-48 bg-base-300 flex items-center justify-center">
                  <span className="text-6xl">
                    🛍️
                  </span>
                </figure>

                <div className="card-body">

                  <h3 className="card-title">
                    Product {item}
                  </h3>

                  <p className="text-sm opacity-60">
                    Amazing quality product from ShopNow.
                  </p>

                  <div className="flex justify-between items-center mt-3">

                    <span className="text-xl font-bold">
                      ₹{999 + item * 100}
                    </span>

                    <button className="btn btn-primary btn-sm">
                      Add to Cart
                    </button>

                  </div>

                </div>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* CTA */}
      <section className="py-20 px-6">

        <div className="max-w-5xl mx-auto bg-primary text-primary-content rounded-2xl p-10 text-center">

          <h2 className="text-3xl md:text-4xl font-bold">
            Ready to Start Shopping?
          </h2>

          <p className="mt-3 opacity-90">
            Explore thousands of products and find
            something you love.
          </p>

          <Link
            to="/products"
            className="btn mt-6"
          >
            Start Shopping
          </Link>

        </div>

      </section>

    </div>
  );
}

export default Home;