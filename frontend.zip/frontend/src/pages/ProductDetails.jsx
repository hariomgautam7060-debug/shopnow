import { Link, useParams } from "react-router-dom";

const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 1499,
    category: "Electronics",
    emoji: "🎧",
    description:
      "Experience high-quality sound with these comfortable wireless headphones. Perfect for music, gaming, calls, and everyday use.",
    rating: 4.5,
    stock: 20,
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 2499,
    category: "Electronics",
    emoji: "⌚",
    description:
      "Track your daily activity, monitor your fitness and stay connected with this stylish smart watch.",
    rating: 4.3,
    stock: 15,
  },
  {
    id: 3,
    name: "Casual T-Shirt",
    price: 799,
    category: "Fashion",
    emoji: "👕",
    description:
      "A comfortable and stylish casual t-shirt made for everyday wear.",
    rating: 4.2,
    stock: 30,
  },
  {
    id: 4,
    name: "Running Shoes",
    price: 1999,
    category: "Fashion",
    emoji: "👟",
    description:
      "Lightweight and comfortable running shoes designed for daily workouts and running.",
    rating: 4.6,
    stock: 12,
  },
  {
    id: 5,
    name: "Laptop Backpack",
    price: 999,
    category: "Accessories",
    emoji: "🎒",
    description:
      "Spacious and durable backpack with dedicated laptop storage and multiple compartments.",
    rating: 4.4,
    stock: 25,
  },
  {
    id: 6,
    name: "Gaming Mouse",
    price: 1299,
    category: "Gaming",
    emoji: "🖱️",
    description:
      "High precision gaming mouse with responsive controls for an enhanced gaming experience.",
    rating: 4.7,
    stock: 18,
  },
];

function ProductDetails() {
  const { id } = useParams();

  const product = products.find(
    (item) => item.id === Number(id)
  );

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-base-200 px-6">
        <h1 className="text-4xl font-bold mb-4">
          Product Not Found
        </h1>

        <Link to="/products" className="btn btn-primary">
          Back to Products
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-base-200 px-6 py-10">

      <div className="max-w-6xl mx-auto">

        {/* Back Button */}
        <Link
          to="/products"
          className="btn btn-ghost mb-8"
        >
          ← Back to Products
        </Link>

        {/* Product Details */}
        <div className="card lg:card-side bg-base-100 shadow-xl overflow-hidden">

          {/* Product Image */}
          <figure className="lg:w-1/2 min-h-[450px] bg-base-300 flex items-center justify-center">
            <span className="text-[150px]">
              {product.emoji}
            </span>
          </figure>

          {/* Product Information */}
          <div className="card-body lg:w-1/2 justify-center">

            <div className="badge badge-primary w-fit">
              {product.category}
            </div>

            <h1 className="text-4xl font-bold mt-3">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mt-3">
              <div className="rating">
                <span className="text-yellow-500 text-xl">
                  ★★★★★
                </span>
              </div>

              <span className="opacity-60">
                {product.rating} / 5
              </span>
            </div>

            {/* Price */}
            <div className="mt-5">
              <span className="text-4xl font-bold text-primary">
                ₹{product.price}
              </span>
            </div>

            {/* Description */}
            <p className="py-6 text-base opacity-70 leading-relaxed">
              {product.description}
            </p>

            {/* Stock */}
            <div className="flex items-center gap-2 mb-5">
              <span className="font-semibold">
                Availability:
              </span>

              <span className="text-success">
                In Stock ({product.stock} available)
              </span>
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-4 mb-6">
              <span className="font-semibold">
                Quantity:
              </span>

              <div className="join">
                <button className="btn join-item">
                  −
                </button>

                <button className="btn join-item">
                  1
                </button>

                <button className="btn join-item">
                  +
                </button>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">

              <button className="btn btn-primary flex-1">
                🛒 Add to Cart
              </button>

              <Link
                to="/checkout"
                className="btn btn-outline flex-1"
              >
                Buy Now
              </Link>

            </div>

          </div>
        </div>

        {/* Extra Information */}
        <div className="grid md:grid-cols-3 gap-6 mt-10">

          <div className="card bg-base-100 shadow-md">
            <div className="card-body text-center">
              <div className="text-3xl">🚚</div>
              <h3 className="font-bold">
                Fast Delivery
              </h3>
              <p className="text-sm opacity-60">
                Quick and reliable delivery.
              </p>
            </div>
          </div>

          <div className="card bg-base-100 shadow-md">
            <div className="card-body text-center">
              <div className="text-3xl">🔒</div>
              <h3 className="font-bold">
                Secure Payment
              </h3>
              <p className="text-sm opacity-60">
                Your payments are secure.
              </p>
            </div>
          </div>

          <div className="card bg-base-100 shadow-md">
            <div className="card-body text-center">
              <div className="text-3xl">↩️</div>
              <h3 className="font-bold">
                Easy Returns
              </h3>
              <p className="text-sm opacity-60">
                Simple and hassle-free returns.
              </p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

export default ProductDetails;