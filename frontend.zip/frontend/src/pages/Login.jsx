import { Link } from "react-router-dom";

function Login() {
  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center px-6 py-12">

      <div className="w-full max-w-md">

        {/* Logo / Heading */}
        <div className="text-center mb-8">
          <Link
            to="/"
            className="text-3xl font-bold text-primary"
          >
            ShopNow
          </Link>

          <h1 className="text-3xl font-bold mt-5">
            Welcome Back
          </h1>

          <p className="opacity-60 mt-2">
            Login to continue shopping
          </p>
        </div>

        {/* Login Card */}
        <div className="card bg-base-100 shadow-xl">

          <div className="card-body">

            {/* Email */}
            <fieldset className="fieldset">
              <legend className="fieldset-legend">
                Email Address
              </legend>

              <input
                type="email"
                className="input input-bordered w-full"
                placeholder="Enter your email"
              />
            </fieldset>

            {/* Password */}
            <fieldset className="fieldset mt-2">
              <legend className="fieldset-legend">
                Password
              </legend>

              <input
                type="password"
                className="input input-bordered w-full"
                placeholder="Enter your password"
              />
            </fieldset>

            {/* Remember + Forgot */}
            <div className="flex justify-between items-center mt-3">

              <label className="label cursor-pointer gap-2">
                <input
                  type="checkbox"
                  className="checkbox checkbox-primary checkbox-sm"
                />

                <span className="text-sm">
                  Remember me
                </span>
              </label>

              <button className="text-sm text-primary hover:underline">
                Forgot Password?
              </button>

            </div>

            {/* Login Button */}
            <button className="btn btn-primary w-full mt-5">
              Login
            </button>

            {/* Divider */}
            <div className="divider">
              OR
            </div>

            {/* Google */}
            <button className="btn btn-outline w-full">
              Continue with Google
            </button>

            {/* Signup */}
            <p className="text-center mt-5 text-sm">
              Don't have an account?{" "}
              <Link
                to="/signup"
                className="text-primary font-semibold hover:underline"
              >
                Create Account
              </Link>
            </p>

          </div>

        </div>

        {/* Back */}
        <div className="text-center mt-6">
          <Link
            to="/"
            className="text-sm opacity-60 hover:opacity-100"
          >
            ← Back to ShopNow
          </Link>
        </div>

      </div>

    </div>
  );
}

export default Login;