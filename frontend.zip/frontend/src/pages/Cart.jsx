import { Link } from "react-router-dom";

const cartItems = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 1499,
    quantity: 1,
    emoji: "🎧",
  },
  {
    id: 3,
    name: "Casual T-Shirt",
    price: 799,
    quantity: 2,
    emoji: "👕",
  },
];

function Cart() {
  const subtotal = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  const delivery = subtotal >= 2000 ? 0 : 99;
  const total = subtotal + delivery;

  return (
    <div className="min-h-screen bg-base-200 px-6 py-10">

      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold">
            Shopping Cart
          </h1>

          <p className="opacity-60 mt-2">
            Review your items before checkout
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">

          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-5">

            {cartItems.map((item) => (
              <div
                key={item.id}
                className="card bg-base-100 shadow-md"
              >
                <div className="card-body">

                  <div className="flex flex-col sm:flex-row gap-5">

                    {/* Image */}
                    <div className="w-full sm:w-32 h-32 bg-base-300 rounded-xl flex items-center justify-center">
                      <span className="text-6xl">
                        {item.emoji}
                      </span>
                    </div>

                    {/* Details */}
                    <div className="flex-1">

                      <div className="flex justify-between gap-4">

                        <div>
                          <h2 className="text-xl font-bold">
                            {item.name}
                          </h2>

                          <p className="text-primary font-semibold mt-2">
                            ₹{item.price}
                          </p>
                        </div>

                        {/* Remove */}
                        <button className="btn btn-ghost btn-sm text-error">
                          Remove
                        </button>

                      </div>

                      {/* Quantity */}
                      <div className="flex justify-between items-center mt-6">

                        <div className="join">

                          <button className="btn join-item">
                            −
                          </button>

                          <button className="btn join-item">
                            {item.quantity}
                          </button>

                          <button className="btn join-item">
                            +
                          </button>

                        </div>

                        <p className="font-bold text-lg">
                          ₹{item.price * item.quantity}
                        </p>

                      </div>

                    </div>

                  </div>

                </div>
              </div>
            ))}

            {/* Continue Shopping */}
            <Link
              to="/products"
              className="btn btn-outline"
            >
              ← Continue Shopping
            </Link>

          </div>

          {/* Order Summary */}
          <div>
            <div className="card bg-base-100 shadow-xl sticky top-6">

              <div className="card-body">

                <h2 className="card-title text-2xl mb-4">
                  Order Summary
                </h2>

                {/* Subtotal */}
                <div className="flex justify-between">
                  <span className="opacity-70">
                    Subtotal
                  </span>

                  <span className="font-semibold">
                    ₹{subtotal}
                  </span>
                </div>

                {/* Delivery */}
                <div className="flex justify-between mt-3">
                  <span className="opacity-70">
                    Delivery
                  </span>

                  <span className="font-semibold">
                    {delivery === 0
                      ? "FREE"
                      : `₹${delivery}`}
                  </span>
                </div>

                <div className="divider"></div>

                {/* Total */}
                <div className="flex justify-between text-xl">
                  <span className="font-bold">
                    Total
                  </span>

                  <span className="font-bold text-primary">
                    ₹{total}
                  </span>
                </div>

                {/* Checkout */}
                <Link
                  to="/checkout"
                  className="btn btn-primary w-full mt-5"
                >
                  Proceed to Checkout
                </Link>

                {/* Security */}
                <div className="text-center mt-4">
                  <p className="text-xs opacity-60">
                    🔒 Secure checkout
                  </p>
                </div>

              </div>

            </div>
          </div>

        </div>

      </div>

    </div>
  );
}

export default Cart;