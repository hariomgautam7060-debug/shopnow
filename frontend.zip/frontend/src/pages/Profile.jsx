import { Link } from "react-router-dom";

function Profile() {
  return (
    <div className="min-h-screen bg-base-200 px-6 py-10">

      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold">
            My Profile
          </h1>

          <p className="mt-2 opacity-60">
            Manage your account and personal information
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">

          {/* Profile Card */}
          <div className="card bg-base-100 shadow-xl">
            <div className="card-body items-center text-center">

              {/* Avatar */}
              <div className="avatar placeholder">
                <div className="bg-primary text-primary-content rounded-full w-28">
                  <span className="text-4xl">
                    H
                  </span>
                </div>
              </div>

              <h2 className="text-2xl font-bold mt-3">
                Hariom Gautam
              </h2>

              <p className="opacity-60">
                hariom@example.com
              </p>

              <div className="badge badge-primary mt-2">
                Customer
              </div>

              <button className="btn btn-outline btn-sm mt-5">
                Edit Profile
              </button>

            </div>
          </div>

          {/* Account Details */}
          <div className="lg:col-span-2 space-y-6">

            {/* Personal Information */}
            <div className="card bg-base-100 shadow-md">

              <div className="card-body">

                <h2 className="card-title">
                  Personal Information
                </h2>

                <div className="grid md:grid-cols-2 gap-5 mt-4">

                  <div>
                    <label className="text-sm opacity-60">
                      Full Name
                    </label>

                    <p className="font-semibold mt-1">
                      Hariom Gautam
                    </p>
                  </div>

                  <div>
                    <label className="text-sm opacity-60">
                      Email
                    </label>

                    <p className="font-semibold mt-1">
                      hariom@example.com
                    </p>
                  </div>

                  <div>
                    <label className="text-sm opacity-60">
                      Phone
                    </label>

                    <p className="font-semibold mt-1">
                      +91 XXXXX XXXXX
                    </p>
                  </div>

                  <div>
                    <label className="text-sm opacity-60">
                      Member Since
                    </label>

                    <p className="font-semibold mt-1">
                      2026
                    </p>
                  </div>

                </div>

              </div>
            </div>

            {/* Account Actions */}
            <div className="card bg-base-100 shadow-md">

              <div className="card-body">

                <h2 className="card-title">
                  Account
                </h2>

                <div className="grid sm:grid-cols-2 gap-4 mt-4">

                  <Link
                    to="/orders"
                    className="btn btn-outline justify-start"
                  >
                    📦 My Orders
                  </Link>

                  <button className="btn btn-outline justify-start">
                    🔒 Change Password
                  </button>

                  <button className="btn btn-outline justify-start">
                    📍 Manage Addresses
                  </button>

                  <button className="btn btn-outline justify-start text-error">
                    🚪 Logout
                  </button>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Profile;